import { Component } from '@angular/core';

@Component({
  selector: 'app-batchlist',
  standalone: true,
  imports: [],
  templateUrl: './batchlist.component.html',
  styleUrl: './batchlist.component.css'
})
export class BatchlistComponent {

}
